# LIT-P01-02 — structured primary literature DISCOVERY/SCREENING (not final adjudication)

- First-pass literature collection covers 5 fixed relationship IDs in the uploaded source packet.
- Distinguish mouse Slco1a4 from human SLCO1A2 (not the same exact receptor gene).
- Each endpoint row describes a tested original model, experimental agent, control and bounded observation; NOT a globally validated receptor property.
- Source-read-depth labels differentiate abstract/excerpt from accessible HTML text. Figure/table locators derived from accessible text do not imply visual verification.
- No complete original PDF figure image/supplement/method audit and no expert biological receptor approval has occurred.
- Not tested is not negative; no observations here validate native blood-to-brain intact *generated* peptide-cargo transport.
- Receptor ranking, docking-fragment approval and Cell 12.5 remain blocked.
- The Google Sheet is the deduplicated publication library. The reviewed ZIP is the only biological update consumed by Cell 12.4i.
- Do not run downstream selection gates from screened-only fields.
