# OmiPep v0.2 Module 01 / LIT-P07-02 — Pass 1 screening

- This package follows the exact LIT-P04-01 _v1_ importer interface. Core files: `references.csv`, `evidence_claims.csv`, `relationship_review.csv`, `review_manifest.json`.
- 5 mouse-to-human relationships; 39 distinct primary research papers; 78 ledger records, **39 study-observation entries and 39 explicit interpretation boundary entries**. A boundary is NOT a separate observed negative experiment.
- This is PRIMARY SOURCE SCREENING. Some primary full-text HTML/results sections and figure legends were accessible. All comprehensive PDF method, full visual-figure, appendices and supplementary, plus expert review are still pending Pass 2. Read-depth is recorded separately by source.
- No approved receptor, luminal fragment, docking target, or Cell 12.5 handoff. All 125 original relationships remain preserved in the local master. UNKNOWN is not absent/zero.

## Mechanistic distinctions and manuscript-critical disagreements

KDR: genuine VEGF-binding VEGFR2 surface receptor, but changes in vascular inflammation and permeability cannot demonstrate peptide shuttle; diabetes can reverse direction of effects.
SLC2A1/GLUT1: physiological small sugar transport vs intact multivalent glucose nanocarrier and mRNA-LNP crossing: distinct molecular routes and competing glucose.
CLDN5: actual specific peptide, antibody, toxin-derived and small molecule ligands OPEN PARACELLULAR junctions, not intact endothelial transcytosis; NHP high-dose convulsions and systemic pathology.
PLVAP: fenestral diaphragm and injury-associated BBB marker, low healthy brain versus substantial fenestrated peripheral tissue exposure, contradictory liver knockout fenestra studies.
SCARB1: primary human brain microvascular HDL transcytosis and human BBB tissue-model LNP delivery are meaningfully positive carrier-specific endpoints; do not generalize to free designed peptide cargo.

## Existing reference library and intake

DOI-primary publication deduplication must be performed before Google Sheet append. The same paper may support more than one relationship but is not automatically a new Sheet publication. Citation keys must be reconciled to existing Sheet identities before final import. Exactly two ledger records per paper are evidence observation and a NOT-NEGATIVE interpretation boundary, not two independently tested experiments.

## Human translational / peripheral context

All original 541-column upstream records and derived 29-column master fields remain unchanged in the user source packet. Per-relationship evidence summaries transcribe source HPA bulk-organ maxima, peripheral EC maxima, immune maxima, human atlas CPM and D02 effects. They are from separate modalities and MUST NOT be ratioed or treated as actual brain-luminal protein detection.

## Scientific and reproducibility limits

- No original 541-column science values altered; source packet SHA-256 recorded.
- Full source figure image/supplementary audit incomplete for all papers; figure/assay locators are preliminary where flagged.
- Gene-specific isoforms and partners not silently conflated.
- Original HDL and LNP BBB-model studies DO report transcytosis or functional delivery; none measures our intended intact designed soluble peptide-cargo. No unpublished sample-level transport is invented.
- This ZIP's structural checks do NOT constitute an actual execution of the user's local Cell 12.4i importer.
