# OmiPep v0.2 Module 01 / LIT-P07-01 — Pass 1 screening

- This package follows the exact LIT-P04-01 _v1_ importer interface. Core files: `references.csv`, `evidence_claims.csv`, `relationship_review.csv`, `review_manifest.json`.
- 5 mouse-to-human relationships; 43 distinct primary research papers; 86 ledger records, **43 study-observation entries and 43 explicit interpretation boundary entries**. A boundary is NOT a separate observed negative experiment.
- This is PRIMARY SOURCE SCREENING. Some primary full-text HTML/results sections and figure legends were accessible. All comprehensive PDF method, full visual-figure, appendices and supplementary, plus expert review are still pending Pass 2. Read-depth is recorded separately by source.
- No approved receptor, luminal fragment, docking target, or Cell 12.5 handoff. All 125 original relationships remain preserved in the local master. UNKNOWN is not absent/zero.

## Mechanistic distinctions and manuscript-critical disagreements

TEK: authentic Ang1/Ang2 surface-binding tyrosine kinase; endogenous ligand-dependent clathrin uptake and vascular signalling are not intact peptide–cargo transcytosis. Tie1/VE-PTP and ligand oligomerization alter uptake; stroke BBB protection is not delivery.
ABCG2: native BBB ABC transporter efflux REDUCES brain drug exposure; directional specificity, ABCB1 redundancy, CSF-vs-parenchyma, intestine/placenta and small extracellular-loop size prevent overinterpretation as an inward peptide shuttle.
ENG: CD105 ECD glyco/disulfide BMP9/ALK1 signalling, soluble shedding and peripheral endothelial sink; anti-ENG scFv immunoliposome binding is non-brain EC antibody targeting, not generated peptide cargo delivery.
ICAM1: exceptionally important preclinical anticarrier literature. Anti-ICAM nanocarriers show model-specific transcytosis and mouse brain therapeutic enzyme delivery; fibrinogen-derived peptide-coated carriers support actual peptide ligand uptake yet typically intracellular/lysosomal routing. Free single peptide–cargo intact blood-to-abluminal delivery remains UNPROVEN and needs independent validation. VCAM outperformed ICAM in a comparison.
PECAM1: anti-PECAM iron oxide carrier BBB-model transcytosis and mouse brain localization, VERSUS distinct two-step nanoparticle study deliberately retaining vascular label because BBB blocks crossing. Epitope-specific uptake, junctional IgD1D2 binding, lung endothelial and platelet/immune sinks and barrier modulation remain.

## Existing reference library and intake

DOI-primary publication deduplication must be performed before Google Sheet append. The same paper may support more than one relationship but is not automatically a new Sheet publication. Citation keys must be reconciled to existing Sheet identities before final import. Exactly two ledger records per paper are evidence observation and a NOT-NEGATIVE interpretation boundary, not two independently tested experiments.

## Human translational / peripheral context

All original 541-column upstream records and derived 29-column master fields remain unchanged in the user source packet. Per-relationship evidence summaries transcribe source HPA bulk-organ maxima, peripheral EC maxima, immune maxima, human atlas CPM and D02 effects. They are from separate modalities and MUST NOT be ratioed or treated as actual brain-luminal protein detection.

## Scientific and reproducibility limits

- No original 541-column science values altered; source packet SHA-256 recorded.
- Full source figure image/supplementary audit incomplete for all papers; figure/assay locators are preliminary where flagged.
- Gene-specific isoforms and partners not silently conflated.
- No sample-level transcytosis measurements or intact designed cargo recovery claimed.
- This ZIP's structural checks do NOT constitute an actual execution of the user's local Cell 12.4i importer.
