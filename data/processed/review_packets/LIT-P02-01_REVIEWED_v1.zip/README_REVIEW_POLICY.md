# LIT-P02-01 -- first-pass evidence screening, no full-paper final adjudication

- Source: fixed five relationship IDs from 12.4f; no upstream omics alterations.
- Original abstracts and some accessible HTML methods/results were screened. Do not infer visual figure or supplemental verification.
- Immune cell uptake, cytosolic proteolysis, hepatocyte virus restriction, endothelial activation and receptor surface availability are different endpoints.
- Native luminal human BBB access, directional intact peptide-cargo transcytosis and abluminal release are UNPROVEN for each of these five in screened literature.
- Unknown means not tested in the screened set, NOT tested negative nor the absence of all literature.
- CD14 membrane versus soluble and CD302 immune versus liver expression are source-specific caveats.
- Each figure locator is explicitly source-inspection-depth labeled; no visually verified figure images.
- First-pass screening is not receptor approval; expert criteria and Cell 12.5 remain blocked.
