# OmiPep v0.2 Module 01 | LIT-R01-01

Pass 1 reconciliation of two relationships; 13 original articles, 26 ledger rows (13 observations, 13 interpretation boundaries, not additional negative experiments). All four inherited PMIDs rechecked. No final expert approval or docking. Source-level abstract plus selected paper and figure-caption excerpts; no systematic full visual figure or supplement review.

ECSCR: surface/junction localization and associated KDR degradation, not direct ECSCR-targeted transport. The Koide article has a correction (PMID 25883266) for Pass 2. IGF1R: construct-dependent antibody delivery and functional cargo; exact intact peptide recovery and native human luminal epitope not established. Preliminary independent contradictory conference report: https://pmc.ncbi.nlm.nih.gov/articles/PMC12739774/ (not counted as full primary paper). Online-first Tian paper published September 18, 2026 (December issue).

All upstream numeric source values preserved; no selection, no exclusions, no new independent measurements. Source hashes rechecked; local 12.4i execution required.
