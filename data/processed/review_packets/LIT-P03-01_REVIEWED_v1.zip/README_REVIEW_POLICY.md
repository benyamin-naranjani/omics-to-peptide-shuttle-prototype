# OmiPep LIT-P03-01 — source-linked screening, not final paper verification

The ZIP is importable by the existing Cell 12.4i. Its evidence conclusions are preliminary.

1. All five source relationship IDs are preserved; immutable 541-column source records are never changed.
2. DDOST has both OST48/AGER1 surface AGE-binding reports and core ER oligosaccharyltransferase/retention studies; native human BBB luminal status unverified.
3. ATP5F1A alpha ectopic binding data are separated from ATP5F1B beta aortic apoA-I/HDL transcytosis; the latter does not prove ATP5F1A alpha-mediated BBB peptide delivery. Source human brain EC atlas CPM=0.0 is kept but not used as automatic exclusion.
4. P4HB means PDIA1, not PDIA6/ERp5. Surface/secreted PDI is redox/injury dependent and implicated in thrombus formation; no intact BBB cargo delivery demonstrated.
5. RACK1's term 'receptor' is a historical kinase-binding scaffold name, not evidence of an extracellular receptor. TMEM256 urinary vesicle detection does not show native brain capillary luminal orientation.
6. Full paper figures, supplements and all bibliographic author details remain to be adjudicated during Pass 2. No receptor selected, no docking fragment authorized, Cell 12.5 remains blocked.
7. 'Not demonstrated in screened studies' is not evidence of a negative result in a transport experiment. No peptide-cargo BBB shuttle transport was directly tested by these studies.
