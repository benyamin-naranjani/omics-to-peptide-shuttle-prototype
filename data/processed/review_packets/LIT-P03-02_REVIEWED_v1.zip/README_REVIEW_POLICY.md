# LIT-P03-02 literature primary-source screening (Pass 1)
- 5 exact mouse-human relationships retained and original 541-column provenance not altered.
- 30 publications are screened using available original abstracts and selected original HTML methods/figures captions; NO claim of complete full-text, all figures, or supplementary audit.
- Rat/mouse microvessel enrichment of ATP8B1 is a genuine primary BBB finding, not proven human blood-side receptor. CDC50A accessory topology critical.
- VMP1 is ER scramblase and autophagy factor, despite source computational surface designation; no native BBB-luminal evidence.
- CIB1 recognizes intracellular integrin tail and is a cytoplasmic EF-hand regulator, not extracellular receptor by default.
- ENT1/SLC29A1 has real mouse BBB small nucleoside transport evidence. It does not demonstrate peptide- or cargo-sized BBB delivery.
- CD52 is a GPI glycopeptide highly expressed in immune/reproductive systems; soluble CD52 binds SIGLEC10/SIGLEC7 in appropriate contexts, the receptor is SIGLEC not CD52.
- No receptor chosen; no target fragment approved; unknowns remain unknown and normal gene expression is not sufficient for human translational conclusion.
- Original full-text figures, supplements and any pending authors/PMID-only records to be adjudicated in Pass 2.
