# LIT-R02-02 | Pass 1

Five relationships, two mouse genes. 14 unique papers (five reused); 44 paired observation/boundary records, not independent experiments. All inherited PMIDs reconciled. No native TNFR1-only BBB generated peptide transport claimed. IFITM unresolved identifier receives mouse/family context only. Source preserved; no exclusions or approvals. Pass 2 full methods, figures, supplements and expert review pending. Local 12.4i untested here.
