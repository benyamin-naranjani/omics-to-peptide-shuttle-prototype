# LIT-P02-02 — initial literature screening

- Authoritative source relationship IDs are those in the 12.4f source ZIP; all five included.
- All 23 primary publications are screened using PubMed/original abstracts and selected accessible publisher/PMC results. Visual figure and supplemental verification is not complete.
- CRITICAL PARALOG WARNING: Rpsa->RPSA and Rpsa->RPSA2 are separate relationships. The six RPSA experimental papers DO NOT directly establish native RPSA2 ligand binding, surface accessibility or BBB trafficking. Zero gene-specific RPSA2 primary studies are included; do not infer 'negative'.
- B3GNT3 glycan effects on adhesion/immune ligands do not make B3GNT3 a blood-facing target. STING ER/Golgi translocation is not BBB transcytosis.
- GRP78 autoantibody-associated brain barrier leakage is NOT intact receptor-mediated therapeutic cargo transport. RPSA bacterial/viral entry is NOT evidence of safe de novo peptide cargo passage.
- Preserve findings explicitly as preliminary. No approved receptor, no docking fragment, no Cell 12.5 handoff.
- A subsequent full-text pass must reconcile original methods, visual figure panels, supplements, mechanistic alternatives and contradictory evidence.
