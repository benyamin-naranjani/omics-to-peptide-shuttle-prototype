# LIT-R03-01 | Pass 1

Five relationships, two mouse genes. 11 unique papers (five reused); 38 paired observation/boundary records, not independent experiments. All inherited PMIDs reconciled. Mouse LY6A vector transport is not human LY6S peptide delivery. IFITM unresolved identifier receives mouse/family context only. Source preserved; no exclusions or approvals. Pass 2 full methods, figures, supplements and expert review pending. Local 12.4i untested here.
