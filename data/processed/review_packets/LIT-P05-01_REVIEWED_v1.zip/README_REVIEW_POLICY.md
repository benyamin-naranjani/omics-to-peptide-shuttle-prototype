# OmiPep v0.2 — Module 01 — LIT-P05-01 screening pass (v1 schema)

Scientific meaning: 31 original studies, 62 ledger records. Each source contributes ONE study-specific observation and ONE nonexperimental scope boundary; the latter is NOT a measured negative and is NOT an independent experiment.

Primary studies were located via DOI/PMID original-publisher, PubMed and accessible PMC pages. Depth is tracked separately per study; a limited number of open HTML methods or figure legends were read opportunistically. **No complete 31-paper image-level, methods-level, supplementary audit was performed.** Full-text PDF/figure visual review, receptor epitope/proteoform constraints and expert adjudication are Pass 2.

**Mechanism safety:** MFNG enzyme changes NOTCH glycans but MFNG is not Notch. GLUL intracellular metabolism/angiogenesis and barrier changes are not GLUL-mediated BBB transport. CRLF2 is a cytokine receptor that must pair with IL7RA and human brain EC atlas CPM is UNASSESSABLE (not zero); rat bulk cortex does not confirm luminal receptor. TNFRSF12A/Fn14 mediates inflammatory permeability and endolysosomal degradation; Lucifer yellow/Evans blue leakage or neutrophil migration is NOT intact drug cargo transcytosis. C1QBP tumour-surface p32 binding by LyP-1/CGKRK is not healthy brain capillary access; LyP-1/tLyP-1 penetration can require neuropilin-1 second receptor.

All original organ-specific HPA RNA measurements and source multi-omics remain in the user's immutable source packet. The 125-row master should not be overwritten or truncated; gene summaries append a contextual surface/immune/peripheral review. The source uses sample-specific HPA nTPM and independent human brain donor CPM — never ratio these directly. Distinguish missing, unmeasured and measured zero.

**Provenance:** source packet SHA-256 is in manifest. Original source was NOT altered. No selected receptors, no selected docking fragments, no Cell 12.5 authorization. No claim that the local importer 12.4i was executed here. CSV schema matches the working LIT-P04-01_REVIEWED_v1.zip by exact header order and field set.

**Retrospective caution:** This packet should be treated as initial *Pass 1 screening*; DOI authorship, complete methods, figure panels, negative results, disease-vs-healthy contexts and supplementary details will be reconciled at Pass 2. In particular, peripheral organ peak HPA expression is a screening risk, NOT evidence of actual peptide-binding sinks.
