# OmiPep v0.2 Module 01 / LIT-P06-01 — Pass 1 screening

- This package follows the exact LIT-P04-01 _v1_ importer interface. Core files: `references.csv`, `evidence_claims.csv`, `relationship_review.csv`, `review_manifest.json`.
- 5 mouse-to-human relationships; 29 distinct primary research papers; 58 ledger records, **29 study-observation entries and 29 explicit interpretation boundary entries**. A boundary is NOT a separate observed negative experiment.
- This is PRIMARY SOURCE SCREENING. Some primary full-text HTML/results sections and figure legends were accessible. All comprehensive PDF method, full visual-figure, appendices and supplementary, plus expert review are still pending Pass 2. Read-depth is recorded separately by source.
- No approved receptor, luminal fragment, docking target, or Cell 12.5 handoff. All 125 original relationships remain preserved in the local master. UNKNOWN is not absent/zero.

## Critical relationship interpretations

TMED2: bona fide ER-Golgi cargo sorting by p24β1 (SMO, TLRs, GPI-APs/Wnt) and embryo/placenta phenotype; NOT demonstrated as blood-facing BBB surface protein. COPI/COPII vesicles are not trans-endothelial shuttling vesicles.
ITGB1BP1 (ICAP-1): cytoplasmic tail binding to ITGB1; the integrin external epitope is NOT ICAP-1. Angiogenic sprouting, ECM and CCM vascular permeability are NOT peptide cargo transit.
SEC11A: SPC-A protease active in endoplasmic reticulum lumen; distinguish SEC11C/SPC-C. Do not equate organelle lumen with BBB luminal vascular surface. Four studies shared with the preceding SEC11C batch.
TMEM147: ER multipass protein interacting with CHRM3/M3R and Nicalin-NOMO-Sec61; trafficking of another receptor to plasma membrane is not TMEM147 blood accessibility.
IDE: human cerebral vessel immunoreactivity, human cerebral EC culture surface signal, and Aβ degradation, with secretion/release mechanisms disputed across brain cell types and conditions. Proteolysis suggests possible peptide stability risk, NOT intact BBB transcytosis. Both 2016 astrocyte secretory pathway evidence and 2018 cell-lysis-controlled challenge retained as mechanistically distinct observations.

## Existing reference-library deduplication

The existing Google Sheet contains some original SEC11C-batch studies. The same stable citation keys are retained in `references.csv` and `evidence_claims.csv` so their additional SEC11A-specific endpoint interpretation can be imported without inventing second publications. Google Sheet should receive ONLY DOI-unique new papers. Note: references.csv contains all 29 reviewed source references, including those already in the library, so the local 12.4i importer must deduplicate by DOI/citation key as in prior batches.

## Human translational / peripheral context

All original 541-column upstream records and derived 29-column master fields remain unchanged in the user source packet. Per-relationship evidence summaries transcribe source HPA bulk-organ maxima, peripheral EC maxima, immune maxima, human atlas CPM and D02 effects. They are from separate modalities and MUST NOT be ratioed or treated as actual brain-luminal protein detection.

## Scientific and reproducibility limits

- No original 541-column science values altered; source packet SHA-256 recorded.
- Full source figure image/supplementary audit incomplete for all papers; figure/assay locators are preliminary where flagged.
- Gene-specific isoforms and partners not silently conflated.
- No sample-level transcytosis measurements or intact designed cargo recovery claimed.
- This ZIP's structural checks do NOT constitute an actual execution of the user's local Cell 12.4i importer.
