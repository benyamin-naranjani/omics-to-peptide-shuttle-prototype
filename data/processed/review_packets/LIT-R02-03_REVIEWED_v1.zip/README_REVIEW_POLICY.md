# LIT-R02-03 | Pass 1

Three relationships. 15 unique papers (two existing keys reused); 30 paired observation/boundary records, not independent experiments or negative results. Inherited PMIDs 40203033 and 24470444 reconciled; SELP had no inherited PMID. No generated peptide cargo transport or receptor approval asserted. Pass 2 full figures, supplements, methods and expert review pending. Local 12.4i not executed here.
