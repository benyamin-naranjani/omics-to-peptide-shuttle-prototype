# LIT-R03-02 | Pass 1

Five relationship records, four mouse genes, 17 unique primary papers, 42 ledger rows. Four ORAI1 studies shared across both mappings, not independent observations. Inherited three PMIDs and OSTC PMC URL resolved. Observation plus interpretation boundary is not two experiments or a negative result. No receptor or fragment approved. Full methods, visual figures, supplements and expert adjudication pending; local importer not executed.
