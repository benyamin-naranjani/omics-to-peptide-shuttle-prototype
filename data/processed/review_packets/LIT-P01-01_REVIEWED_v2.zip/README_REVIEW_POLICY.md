# LIT-P01-01 v2 — Scientific evidence upgrade

## Scope
Five relationships retained: NME1, ABCB1, VIM, PDIA6, IGFBP7. Preserve all 125 upstream relationships and the original 541-column dossier. Version 1 was a primary-source screen; version 2 preserves it as history and adds endpoint-specific observations, source-depth qualifications and structured receptor constraints.

**Not a completed systematic review or biological shortlist.** Abstract-only and excerpt-only studies remain pending full-text Methods, figures and supplement adjudication. Figure-level locations are present only where available source text supported them. The studies do not establish blood-to-brain transcytosis of a new intact peptide cargo for any of these five.

## Key improvements
* Multiple experimental endpoints can reference one DOI, with a stable claim ID.
* Study-level reported result is distinct from its applicability to the native BBB and to an engineered peptide cargo.
* An absent assay is `not_tested`, never a negative experimental result.
* VIM PAL-E antigen dispute (`Xu2004` vs `Niemela2005`) is explicitly cross-linked.
* ABCB1 transport direction is restricted to efflux/brain-to-blood Aβ clearance, not inward shuttle; Schinkel knockout, opposite antibody-based localization interpretation added.
* NME1/NME2 and ecto-NDPK specificity; PDIA6 vs KDELR1 binding; IGFBP7 soluble/HSPG dependence remain explicit.
* No changes to receptor selection, any original `verified_*` columns, manuscript merit ranking or ColabFold.

## Methodological policy
1. Figure citations are exact when confirmed in an open primary source; no invented panel IDs.
2. `observed_in_tested_model` does not mean native luminal BBB localization or intact cargo transfer.
3. `primary_source_screened_not_complete_full_text_adjudication` is deliberately not final verification. Final human/rodent applicability must be signed off separately.
4. Five relationships in a batch can produce many claims and references. Source and reviewed ZIPs serve different purposes. Only the highest review package version for each batch is active in the importer.
5. Original data are preserved; manual scientific adjudications are never auto-overwritten.

## Priority follow-up
* Confirm all 25 primary papers, and complete Methods/Figures/Supplements for papers available only at abstract level.
* Reconcile antibody specificity and actual native luminal topology before biological ranking.
* Track experimental cargo integrity and paired blood-to-brain versus brain-to-blood direction in prospective BBB assays.
