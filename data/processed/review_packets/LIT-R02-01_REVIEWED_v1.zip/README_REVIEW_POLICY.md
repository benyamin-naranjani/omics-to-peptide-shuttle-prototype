# OmiPep v0.2 M01 | LIT-R02-01

Pass 1: 14 papers, 28 paired observation/boundary ledger rows, not independent experiments. Two inherited sources reconciled. Three SSR4 references reuse SSR2 batch citation keys. Neither relationship has direct BBB peptide cargo transport evidence in these screened sources. Source immutable; no approval or exclusion. Full visual figures, supplementary methods and expert assessment pending; local importer execution required.
