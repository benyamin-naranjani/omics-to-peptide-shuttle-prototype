OmiPep Module 01 | LIT-P01-01 reviewed literature screening v1

This reviewed ZIP is an immutable INPUT artifact for the reusable Cell 12.4g importer, NOT a regenerated raw-source packet.
The original source packet stays unchanged. Literature claims are annotated with source-read depth.
The batch remains SCIENTIFICALLY OPEN until any required full-text methods and expert checks are complete.
These references are PRIMARY STUDIES; the DOI/PMID identities were screened against web publisher/PubMed metadata,
and missing bibliographic details are specifically marked. Literature absence never equals negative proof.
No paper establishes blood-to-brain abluminal delivery of an intact generated peptide cargo via these targets.
PAL-E identity conflict explicitly flagged. ABCB1 efflux is directionally distinct from shuttle import.
Local original omics/data provenance is upstream; these files do not edit that dataset.
