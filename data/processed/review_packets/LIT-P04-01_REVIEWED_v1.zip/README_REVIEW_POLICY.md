# LIT-P04-01 literature screening — Pass 1

- Frozen source ZIP SHA256: ce8c1c2ae4276a4f8de68e663eac7caaa0fa1b4b0c9b372a435a2d64c58bbcae
- Exactly five source relationships; 29/541 input scientific columns untouched.
- Observations are model/agent/assay-specific, from original primary abstracts and selected original HTML sections; none represents completed full-figure and supplementary verification.
- No human native BBB blood-side accessibility or intact blood-to-brain designed peptide cargo is confirmed by this screen.
- RAB11A vs RAB11B Aβ40 study includes explicit negative RAB11A isoform result in reverse-direction transport.
- SDCBP is intracellular adaptor; do not ascribe syndecan/VEGFR2 ectodomain to it.
- CALR can be ER, secreted, or transiently cell surface under cell stress; immune-clearance context.
- CLIC1 membrane-associated redox state is not necessarily outward receptor epitope.
- LRP8 evidence warrants follow-up for a native BBB shuttle route; a twofold anti-LRP8 antibody brain signal is not proof of intact attached peptide cargo reaching parenchyma.
- No automatic receptor exclusions, target approval, docking or claimed full methods/figure adjudication.
- Pass 2: inspect full original articles, figure images and supplementary files, antibody specificity, precise models and signal controls, and review with experts.

Per-gene paper and claim counts: {
  "RAB11A": {
    "publications": 4,
    "endpoints": 8
  },
  "SDCBP": {
    "publications": 5,
    "endpoints": 10
  },
  "CALR": {
    "publications": 5,
    "endpoints": 10
  },
  "CLIC1": {
    "publications": 6,
    "endpoints": 12
  },
  "LRP8": {
    "publications": 6,
    "endpoints": 12
  }
}
