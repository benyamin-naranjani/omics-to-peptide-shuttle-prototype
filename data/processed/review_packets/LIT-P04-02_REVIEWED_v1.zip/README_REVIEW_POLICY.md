# LIT-P04-02 literature screening - Pass 1 / legacy-v1 importer schema

- Source ZIP SHA256: d8797faa7c94dc58bd1f582654f8507cec5fb7c7413ccef30175aac3006a409f.
- This is a SCHEMA-ONLY REPAIR of the originally delivered LIT-P04-02 source screening.
- Exactly five source relationships: SMIM7, AP2S1, TMEM167A, PARK7, PHB1.
- References: 24 unique DOI-identified primary studies.
- Evidence_claims: 48 rows, **24 reported study observations + 24 interpretation boundaries**.
- The 24 interpretation boundaries are explicitly NOT separate experiments, NOT measured negatives, and NOT evidence that transcytosis is absent.
- The boundary rows each refer back to the same paper, preserving the limits of inference.
- Original screening notes retained; full primary methods, actual figure images, supplements and expert adjudication pending.
- No native human brain BBB receptor-mediated blood-to-brain intact peptide-cargo transport shown.
- In particular, PHB1 adipose targeting is not brain targeting; AP2S1 is an intracellular adaptor;
  TMEM167A controls intracellular vesicle traffic; PARK7 ischemia signaling is not cargo transcytosis.
- Retracted Tat-DJ-1 paper was excluded from reference claims in source screening.
- None of the five relationships is selected; no receptor docking or fragment approval.
- Preserves original source packet separately; no upstream data changes.
- Three importer-facing CSVs and manifest mirror working LIT-P04-01_REVIEWED_v1.zip.
- Count of evidence-claim ROWS is not count of independent positive experiments.
- Do not use this schema-only repair as a claim of full text or visual-figure verification.
