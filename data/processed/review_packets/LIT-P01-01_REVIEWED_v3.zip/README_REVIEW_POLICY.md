# OmiPep v0.2 — LIT-P01-01 reviewed literature package v3

This is a **screening-pass scientific evidence package**, NOT complete full-text/figure adjudication.
Supersedes v2. It remains compatible with existing Cell 12.4i importer.

## What changed relative to v2
* Preserved all 25 unique source publications and all 59 original endpoint claims.
* Reconciled 17 newly inspected, method-specific observations onto 17 **existing** claims.
  This avoids counting the same experiment twice.
* Added claim-level methodology, tested controls, source figure/section locators,
  source read depth, limits, and explicit image/supplement verification flags.
* Added the full 25-paper source-inspection gate and an auditable observation-to-claim map.
* Updated ABCB1 rat brain endothelium polarity summary to include the reported
  dual-face immunogold measurements rather than luminal-only shorthand.
* Original 125-row source dossier, original 29-column master, and biological
  selection/verified_* fields are **not changed** by this package.

## Source limitations and rigor
* Figures were NOT visually verified from images as a group; captions and results
  text may have been inspected in original-source HTML for some papers.
* Supplementary methods review is incomplete for all indexed sources.
* Findings from peripheral vessels, tumour cells, HUVEC, HEK293T, microbial
  invasion and brain-to-blood efflux are not transmuted into BBB blood-to-brain
  intact peptide-cargo transport evidence.
* No receptor is approved for docking/selection, no final source adjudication.
* 7 papers have original full HTML methods/results and captions inspected;
  2 have original PDF text without verified figure images; 16 have abstracts
  or source excerpts only. These are source-access tiers, not evidence grades.

## How it is imported
Keep original `LIT-P01-01_REVIEWED_v1.zip` and `_v2.zip` as history.
Place `_v3.zip` in `data/processed/review_packets/` and run existing
`%run -i 12_4i_rebuild_endpoint_evidence_master_v2.py`.
The highest version number is selected. The normal 47-column master refreshes.
All 17 method annotations remain in the cumulative endpoint claim ledger; the
master intentionally contains concise summaries, not every method/figure detail.

## Full-text completion workflow
Later replace with a formally reviewed version only after confirming all
required source text, figure images, and supplementary details, while preserving
explicit inaccessible/unknown statuses. The Google Sheet already includes these
25 publications; no new rows or duplicate DOI entries are needed now.
