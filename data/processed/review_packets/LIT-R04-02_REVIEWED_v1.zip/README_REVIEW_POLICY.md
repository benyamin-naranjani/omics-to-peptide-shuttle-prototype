# LIT-R04-02 | Pass 1

Five relationship records, five mouse genes, 17 unique primary papers, 34 ledger rows. Six explicit inherited PMIDs resolved. CD74 upstream count of one directly reviewed PMID has no identifier in supplied packet; independently screened studies do not verify that unidentified paper. One reference reused from LIT-P08-01. Observation plus interpretation boundary is not two experiments or a negative result. No receptor or fragment approved. Full methods, visual figures, supplements and expert adjudication pending; local importer not executed.
