# OmiPep Module 01 — LIT-P05-02 Pass-1 original-publication screening

35 unique DOI-identified publications across 5 mouse-to-human relationships, 70 ledger records: **35 primary study observations and 35 interpretation boundaries**. Boundaries are not measurements or independent negative results. Some sources are context/control experiments (including ACTN4, a different isoform) explicitly labelled, not direct receptor endpoint studies. Primary abstracts and selected open HTML sections/figure legends inspected; NO comprehensive visual figure, PDF, supplement, or assay replication audit. First-author fields explicitly unresolved where not confidently verified; do not interpret placeholder as verified bibliographic identity.

ITM2C/Bri3: type II BRICHOS and APP biology; NOT neuronal-to-vascular extrapolation, and BRI2 results NOT BRI3 results.
SLC7A5/LAT1: authentic rat native BBB luminal membrane and small amino-acid/drug/prodrug movement. Strong positive **small-substrate** BBB context, but alternating-access solute antiporter is NOT a macromolecular endocytic shuttle; no evidence of transport of 20-aa engineered peptide-cargo. Heterodimer partner SLC3A2 and physiological amino-acid competition are relevant.
SEC11C: ER signal peptidase subunit; ER luminal is NOT blood/BBB luminal; separate SEC11A from SEC11C conclusions.
TMEM88: dual-membrane Wnt regulator, crucial VWV DVL-binding motif is cytosolic, not a blood-facing motif; MVB-localized Wnt complex is not delivered cargo.
ACTN1: cytoskeletal junction, ACTN4 confounding, 70-kDa dextran endothelial leak is paracellular barrier sieving, not BBB cargo transcytosis; platelet safety.

Original supplied 541-column provenance data and HPA organ nTPM retained unchanged in source packet (source SHA recorded in manifest), not recalculated or conflated with human atlas CPM. Unknown is not measured zero. No approved structural fragment, receptor or Cell 12.5 authorization. Importer version 12.4i not run locally. File schemas and hash manifests checked against working LIT-P04-01 v1.

CROSS-BATCH DOI RECONCILIATION: DOI 10.1016/j.neuroscience.2008.06.015 was previously indexed as BBB_biotin2008 (LIT-P01-02). Its P05-02 LAT1 claim has been aligned to this same citation key. The Google Sheet retains exactly one publication row for this DOI; the P05-02 packet still includes a citation row to preserve locally resolvable claim references. A future importer may deduplicate that repeated publication identity by DOI.
