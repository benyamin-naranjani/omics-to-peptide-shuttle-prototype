# OmiPep v0.2 Module 01 / LIT-P06-02 — Pass 1 screening

- This package follows the exact LIT-P04-01 _v1_ importer interface. Core files: `references.csv`, `evidence_claims.csv`, `relationship_review.csv`, `review_manifest.json`.
- 5 mouse-to-human relationships; 39 distinct primary research papers; 78 ledger records, **39 study-observation entries and 39 explicit interpretation boundary entries**. A boundary is NOT a separate observed negative experiment.
- This is PRIMARY SOURCE SCREENING. Some primary full-text HTML/results sections and figure legends were accessible. All comprehensive PDF method, full visual-figure, appendices and supplementary, plus expert review are still pending Pass 2. Read-depth is recorded separately by source.
- No approved receptor, luminal fragment, docking target, or Cell 12.5 handoff. All 125 original relationships remain preserved in the local master. UNKNOWN is not absent/zero.

## Mechanistic distinctions and contradictions

LAMP2: lysosomal luminal domain, LAMP2 isoforms, VSMC vasculopathy and neuronal stroke. These are not blood-facing brain EC ligand binding.
CD81: authentic extracellular tetraspanin EC2 loop and CD81 antibodies modulate inflammatory brain EC/monocyte migration. Leukocyte transendothelial migration is not intact peptide delivery. Extensive extra-brain and immune expression raises sinks.
CYBA: p22phox ROS oxidase subunit with complex-shielded small exterior loops; NOX2/CYBB knockout studies are not CYBA-specific. Direct Cyba mutant stroke and immune effects are preserved.
LRP6: WNT-dependent BBB barrier regulation, context-dependent signalling internalization and multi-protein WNT complexes, but no intact designed peptide cargo shuttling. Explicitly conflicting 2006 and 2007/2008 anthrax-toxin LRP6 requirement findings are retained.
MFSD2A: mouse native luminal brain EC lipid symporter transporting LPC-DHA with severe human microcephaly loss-of-function context. It **suppresses** caveolin-mediated transcytosis in healthy BBB; no designed 20 aa peptide–cargo transport has been demonstrated.

## Existing reference library and intake

No publication-level duplicates detected against the connected Sheet as of the preflight; use DOI-primary deduplication again at commit time. References.csv is the paper-level source list; exact 2x claim rows represent observations plus interpretation boundaries, not independent experiments.

## Human translational / peripheral context

All original 541-column upstream records and derived 29-column master fields remain unchanged in the user source packet. Per-relationship evidence summaries transcribe source HPA bulk-organ maxima, peripheral EC maxima, immune maxima, human atlas CPM and D02 effects. They are from separate modalities and MUST NOT be ratioed or treated as actual brain-luminal protein detection.

## Scientific and reproducibility limits

- No original 541-column science values altered; source packet SHA-256 recorded.
- Full source figure image/supplementary audit incomplete for all papers; figure/assay locators are preliminary where flagged.
- Gene-specific isoforms and partners not silently conflated.
- No sample-level transcytosis measurements or intact designed cargo recovery claimed.
- This ZIP's structural checks do NOT constitute an actual execution of the user's local Cell 12.4i importer.
