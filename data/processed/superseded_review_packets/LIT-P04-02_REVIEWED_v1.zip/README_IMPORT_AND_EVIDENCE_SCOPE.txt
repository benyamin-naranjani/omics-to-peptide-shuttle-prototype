LIT-P04-02 | DOI-verified primary literature screening | OmiPep M01

INPUT: source packet from Cell 12.4f; five exact relationship IDs, source dossier unchanged.

PACKET MEMBERS:
reference_index.csv                24 DOI-deduplicated papers in the connected Google Sheet 12-column schema
endpoint_evidence_records.csv       48 rows: 24 empirically observed endpoints + 24 explicit NOT-MEASURED interpretation boundaries; boundary records are NOT negative results
relationship_summaries.csv          five relationship-level syntheses
expert_master_29_columns_screened.csv, literature_worklist_38_columns_screened.csv  source-format enrichment without disturbing source fields
excluded_retracted_studies.csv      one formally retracted PARK7/Tat-DJ1 study excluded from positive library/claims
LIT-P04-02_full_provenance_541_columns.csv    original five source rows unmodified
LIT-P04-02_source_literature_fields.csv     original upstream context unmodified
LIT-P04-02_packet_manifest.json      original Cell12.4f source manifest
review_manifest.json                QA and SHA256 hashes

IMPORTANT: This package has been validated for internal CSV schema, provenance and DOI uniqueness; it has NOT been tested against the user's local Cell 12.4i script (uncommitted/not available in current GitHub branch). Thus importer compatibility is not yet confirmed. If 12.4i refuses the package, retain source files and share its required schema for lossless conversion.

Statuses: screened/endpoint-limited; full-text methods, figures, supplementary and expert adjudication remain outstanding. Both Cell 12.5 and any docking-fragment approval remain blocked.
