# OmiPep v0.2 — LIT-P01-01 primary-source method/figure completion audit

**Date:** 21 November 2026. **Scope:** First five mouse–human relationships; unchanged 25-paper/59-claim v2 package. **Status:** interim scientific verification; no final receptor adjudication or approval.

## Exact audit of existing reviewed v2 evidence

- Papers: **25**; endpoint-claim records: **59**; relationships: **5**.
- Read-depth declarations: **6 partial full article**, **10 abstract+excerpts**, **9 abstract/metadata only**.
- Claims lacking explicit figure/table locator: **22/59**; also **22/59** missing comparator/control and **22/59** missing explicit assay/readout.
- This is a *schema completeness / partial source assessment*, **not** proof that experimental conclusions are correct. Source references may be reassessed.
- Source PDF figure screenshots were not consistently accessible; **do not mark any paper fully adjudicated based solely on figure text/captions**.

## Source-specific method and figure observations checked in this pass

| Reference | Method, figure or control | Defensible interpretation and boundary |
|---|---|---|
| [Moreno2014](https://pmc.ncbi.nlm.nih.gov/articles/PMC4150062/) | Endothelial-junction ATP/contractility perturbations; original paper/PMC results; junction-local ATP/ADP and contractility; perturbation of Nm23 and partners | Junctional protein interaction does not demonstrate blood-facing NME1 epitope or shuttle |
| [Beaulieu1997](https://pmc.ncbi.nlm.nih.gov/articles/PMC1218702/) | Luminal enrichment and purity controls; paper primarily a membrane-fractionation study; P-gp Western blots; GLUT1, glial and intracellular contamination markers | Abluminal fractions were not directly quantified in that study; no drug/peptide transcytosis assay |
| [Bendayan2006](https://pmc.ncbi.nlm.nih.gov/articles/PMC3957801/) | Original Fig. 2 and Fig. 4; Table 1 quantitative subcellular labeling; immunogold electron microscopy; anti-GFAP and anti-P-gp labels | Antibody immunolocalization supports localization, not an uptake or transcytosis mechanism |
| [PICALM_ABCB1_2018](https://bauerhartzlab.org/wp-content/uploads/2023/08/181001_Storck.pdf) | Figs. 6-10 (co-inhibition; LRP1/P-gp/PICALM/Rab11 co-IP and colocalization); Aβ directional transport, simultaneous inhibition, co-IP and colocalization | Specifically brain-to-blood Aβ clearance; no blood-to-brain intact designed peptide-cargo release; co-IP not proof of direct receptor binding |
| [Xu2004](https://pmc.ncbi.nlm.nih.gov/articles/PMC517872/) | Original results discuss a PAL-E reactive vimentin interpretation; purification, tandem mass spectrometry, PAL-E staining | Molecular identification is disputed by a later orthogonal PLVAP/PV-1 study |
| [Niemela2005](https://pubmed.ncbi.nlm.nih.gov/16099878/) | Primary article abstract reports PAL-E antigen is PLVAP/PV-1; double staining; cross-immunoprecipitation; transfectant comparison | Direct contradiction with Xu2004; do not treat PAL-E staining as VIM-specific evidence |
| [Pall2011](https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0029305) | Figs. 1, 2, 3, 5, 6; GST negative control, recombinant VIM competition, WT vs Vim-/- comparison; pull-down/MS, ITC/SPR, live surface biotinylation, FACS, EEA1/CD63 confocal | Internalization and early-endosomal arrival do not equal intact BBB transcytosis; mouse lung ECs not mouse brain ECs |
| [Zhou2026](https://www.frontiersin.org/journals/immunology/articles/10.3389/fimmu.2026.1793594/full) | Primary 2026 Frontiers Results/Figures (VIM raft fractions, invasion and injury); VIM changes, NF-kB markers, inhibitor perturbation, bacterial counts/neurological scores | Pathogen invasion and BBB damage must not be repurposed as safe therapeutic cargo delivery |
| [Bartels2019](https://www.cellphysiolbiochem.com/Articles/000059/full/000059.html) | Figs. 1, 4, 5; PDIA6 KDEL requirement, shRNA KDELR1, trafficking inhibitors; PDIA6 +/- KDEL mutants, secretion blots, nonpermeabilized flow, clathrin/caveolin inhibitors | Engineered HEK293T surface association is not native brain-luminal PDIA6 or BBB transcytosis |
| [Bar2020](https://link.springer.com/article/10.1186/s12987-020-00188-2) | Figs. 1-5: E13.5 cortical-lung EC RNA, E12.5 CNS IHC, skin Miles assay, adult parenchymal distribution and choroid plexus; microarray, immunofluorescence, Miles skin Evans-blue permeability assay | The permeability assay was in skin, not BBB; secreted/angiocrine protein not a membrane shuttle receptor; developmental expression differs from adult |
| [Cai2026](https://pmc.ncbi.nlm.nih.gov/articles/PMC13510594/) | Primary Figure sections on heparin-induced D6 dodecamer and mutant cell aggregation; heparin-dependent cryo-EM; IgC2/heparin-binding mutants; aggregation assay | Soluble ligand/HSPG binding and multimerization do not show direct receptor-mediated BBB uptake |

## Definition of “deep review completed” for future batches

A source may become `figure_methods_adjudicated` only when (i) bibliographic DOI/PMID identity is crosschecked, (ii) original full text or user-provided author manuscript is read, (iii) *relevant original* figures, tables and legends are inspected, (iv) assay, comparator, sample size and statistical context are extracted, (v) biological system, species, isoform, agent and transport direction are specified, (vi) all endpoint claims are split into separate records as needed, and (vii) contradictions/unknowns and full-text access limitations are recorded. If access is unavailable, keep `fulltext_unavailable` or `partial_screening`; do not impute validation.

## Next scientific action

Finish the outstanding paper-by-paper source verification, including figure images and supplements, and then issue `LIT-P01-01_REVIEWED_v3.zip` as a **superseding** reviewed package; leave `v2` archived. Do not import this audit-only archive through Cell 12.4i; it is not a reviewed evidence ZIP.

**Cross-batch insight:** Independent native luminal-surface proteomics and polarized membrane-localization studies from 2024–2026 are potential orthogonal checks for the complete 125-row universe, not automatic additions to the candidate list.
